"""JSONL logging and checkpoints (per rank; rank 0 aggregates)."""
from __future__ import annotations
import json, os, time
import torch


class Logger:
    def __init__(self, outdir, rank):
        os.makedirs(outdir, exist_ok=True)
        self.path = os.path.join(outdir, f"log_rank{rank}.jsonl")
        self.f = open(self.path, "a", buffering=1)

    def __call__(self, record: dict):
        record["t_wall"] = time.time()
        self.f.write(json.dumps(record) + "\n")


def save_ckpt(outdir, rank, **tensors):
    os.makedirs(outdir, exist_ok=True)
    torch.save({k: (v.cpu() if torch.is_tensor(v) else v) for k, v in tensors.items()},
               os.path.join(outdir, f"ckpt_rank{rank}.pt"))


def load_ckpt(outdir, rank):
    p = os.path.join(outdir, f"ckpt_rank{rank}.pt")
    return torch.load(p) if os.path.exists(p) else None
