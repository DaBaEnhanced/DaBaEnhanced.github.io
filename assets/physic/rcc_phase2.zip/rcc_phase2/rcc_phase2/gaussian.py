"""Free-fermion (Gaussian) states on graphs: ground-state correlation matrices,
batched subset entropies, and mutual information.

Matter Hamiltonian:  H = -J * A  +  diag(mass_i)   (single-particle matrix),
ground state at half filling. mass patterns: 'none' (critical, log-law
entanglement expected), 'stagger' (gapped on bipartite graphs, area law),
'random' (+/- Delta, generically gapped/localised).

Entropies are in nats. All heavy steps are batched torch.linalg calls and run
on GPU when available.
"""
from __future__ import annotations
import torch


def matter_hamiltonian(A, J=1.0, delta=0.0, pattern="none", seed=0):
    n = A.shape[0]
    H = -J * A.clone()
    if delta and pattern != "none":
        if pattern == "stagger":
            # 2-colouring via BFS (exact on bipartite graphs; best-effort otherwise)
            col = -torch.ones(n, dtype=torch.long)
            for s in range(n):
                if col[s] >= 0:
                    continue
                col[s] = 0
                stack = [s]
                while stack:
                    u = stack.pop()
                    for v in torch.nonzero(A[u] > 0).flatten().tolist():
                        if col[v] < 0:
                            col[v] = 1 - col[u]
                            stack.append(v)
            sgn = torch.where(col == 0, 1.0, -1.0)
        elif pattern == "random":
            g = torch.Generator().manual_seed(seed)
            sgn = torch.where(torch.rand(n, generator=g) < 0.5, 1.0, -1.0)
        else:
            raise ValueError(pattern)
        H = H + torch.diag(delta * sgn)
    # tiny jitter lifts exact zero modes so half filling is unambiguous
    g2 = torch.Generator().manual_seed(seed + 1)
    H = H + torch.diag(1e-9 * torch.randn(n, generator=g2))
    return H


def ground_corr(H, filling=0.5):
    """Correlation matrix C_ij = <c_i^dag c_j> of the ground state."""
    w, V = torch.linalg.eigh(H)
    nocc = int(round(H.shape[0] * filling))
    Vo = V[:, :nocc]
    return Vo @ Vo.conj().T, w


def _binary_entropy(nu):
    nu = nu.clamp(1e-12, 1 - 1e-12)
    return -(nu * nu.log() + (1 - nu) * (1 - nu).log())


def subset_entropies(C, subsets, batch=512):
    """Entropies S(A) for a list of equally-sized index tensors, batched on GPU.
    subsets: LongTensor (P, m). Returns (P,) tensor."""
    P, m = subsets.shape
    out = torch.empty(P, dtype=torch.get_default_dtype(), device=C.device)
    for a in range(0, P, batch):
        idx = subsets[a:a + batch].to(C.device)
        sub = C[idx[:, :, None], idx[:, None, :]]           # (b, m, m)
        nu = torch.linalg.eigvalsh(sub)
        out[a:a + batch] = _binary_entropy(nu).sum(-1)
    return out


def entropy(C, idx):
    nu = torch.linalg.eigvalsh(C[idx][:, idx])
    return float(_binary_entropy(nu).sum())


def pair_mutual_information(C, cells, pairs, batch=256):
    """I(i:j) = S_i + S_j - S_ij for cell pairs. cells: list of LongTensors
    (possibly unequal sizes); pairs: LongTensor (P, 2). Returns (P,) tensor."""
    S_cell = torch.tensor([entropy(C, c) for c in cells], device=C.device)
    P = pairs.shape[0]
    out = torch.empty(P, device=C.device)
    # group union subsets by size for batching
    sizes = {}
    for p in range(P):
        i, j = int(pairs[p, 0]), int(pairs[p, 1])
        u = torch.cat([cells[i], cells[j]])
        sizes.setdefault(u.numel(), []).append((p, u))
    for m, items in sizes.items():
        idxs = torch.stack([u for _, u in items])
        Su = subset_entropies(C, idxs, batch=batch)
        for k, (p, _) in enumerate(items):
            i, j = int(pairs[p, 0]), int(pairs[p, 1])
            out[p] = S_cell[i] + S_cell[j] - Su[k]
    return out.clamp_min(0.0), S_cell
