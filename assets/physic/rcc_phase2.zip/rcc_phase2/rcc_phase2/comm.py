"""Distributed communication wrapper.

Primary backend: Lightning Fabric (DDP). Falls back to raw torch.distributed
(if launched under torchrun/SLURM with env vars set), and finally to a
single-process no-op mode, so every experiment runs identically on a laptop,
a single multi-GPU node, or a multi-node cluster.

Roles in this codebase: ranks are *replicas* (independent seeds, or rungs of a
parallel-tempering ladder). There is no gradient sync; we only need device
placement, rank identity, barriers, and object gather/broadcast.
"""
from __future__ import annotations
import os
import pickle
import torch


class Comm:
    def __init__(self, devices: str | int = "auto", precision_fp64: bool = True):
        self.fabric = None
        self._dist = False
        if precision_fp64:
            torch.set_default_dtype(torch.float64)
        try:
            from lightning_fabric import Fabric  # standalone package
        except ImportError:
            try:
                from lightning.fabric import Fabric  # bundled package
            except ImportError:
                Fabric = None
        if Fabric is not None:
            ndev = self._ndev(devices)
            strategy = "ddp" if (ndev > 1 or os.environ.get("SLURM_NTASKS", "1") != "1"
                                 or "RANK" in os.environ) else "auto"
            self.fabric = Fabric(accelerator="auto", devices=devices, strategy=strategy)
            self.fabric.launch()
            self.rank = self.fabric.global_rank
            self.world = self.fabric.world_size
            self.device = self.fabric.device
        elif "RANK" in os.environ:
            torch.distributed.init_process_group(
                backend="nccl" if torch.cuda.is_available() else "gloo")
            self._dist = True
            self.rank = torch.distributed.get_rank()
            self.world = torch.distributed.get_world_size()
            if torch.cuda.is_available():
                torch.cuda.set_device(self.rank % torch.cuda.device_count())
                self.device = torch.device("cuda", self.rank % torch.cuda.device_count())
            else:
                self.device = torch.device("cpu")
        else:
            self.rank, self.world = 0, 1
            self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    @staticmethod
    def _ndev(devices) -> int:
        if devices == "auto":
            return max(1, torch.cuda.device_count()) if torch.cuda.is_available() else 1
        if isinstance(devices, int):
            return devices
        try:
            return len(devices)
        except TypeError:
            return 1

    # ---- collectives (object-level; small payloads only) ----
    def barrier(self):
        if self.fabric is not None:
            self.fabric.barrier()
        elif self._dist:
            torch.distributed.barrier()

    def gather_obj(self, obj):
        """Gather a picklable object from every rank to rank 0. Returns list on
        rank 0, None elsewhere (list of length 1 in single-process mode)."""
        if self.world == 1:
            return [obj]
        payload = torch.frombuffer(bytearray(pickle.dumps(obj)), dtype=torch.uint8)
        if self.fabric is not None:
            n = torch.tensor([payload.numel()], device=self.device)
            ns = self.fabric.all_gather(n).flatten().tolist()
            buf = torch.zeros(max(ns), dtype=torch.uint8, device=self.device)
            buf[: payload.numel()] = payload.to(self.device)
            gathered = self.fabric.all_gather(buf)          # (world, maxlen)
            if self.rank != 0:
                return None
            out = []
            for r in range(self.world):
                raw = bytes(gathered[r][: int(ns[r])].cpu().numpy().tobytes())
                out.append(pickle.loads(raw))
            return out
        objs = [None] * self.world
        torch.distributed.all_gather_object(objs, obj)
        return objs if self.rank == 0 else None

    def exchange_scalar(self, value: float, partner: int) -> float:
        """Symmetric scalar exchange with a partner rank (parallel tempering)."""
        if self.world == 1 or partner < 0 or partner >= self.world:
            return value
        t = torch.tensor([value], device=self.device)
        if self.fabric is not None:
            allv = self.fabric.all_gather(t).flatten()
            return float(allv[partner])
        allv = [torch.zeros_like(t) for _ in range(self.world)]
        torch.distributed.all_gather(allv, t)
        return float(allv[partner])

    def broadcast_obj(self, obj, src: int = 0):
        if self.world == 1:
            return obj
        lst = [obj]
        if self.fabric is not None:
            # fabric.broadcast works on tensors/objects in recent versions
            return self.fabric.broadcast(obj, src=src)
        torch.distributed.broadcast_object_list(lst, src=src)
        return lst[0]
