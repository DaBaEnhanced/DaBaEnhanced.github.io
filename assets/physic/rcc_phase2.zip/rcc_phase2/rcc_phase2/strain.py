"""Capacity-load response: the gamma probe (Section 13.4) and two-load binding.

A 'load' weakens hoppings inside a ball B by factor (1 - eps): reduced link
capacity. We then measure two fractional responses:

  clock proxy   d_alpha = fractional reduction of the local energy scale
                alpha_i = sqrt(<i|H^2|i>) averaged over B (the g_00 side);
  spatial proxy d_ell   = fractional lengthening of emergent distances across
                B, from the MI metric recomputed in the loaded ground state
                (the g_ij side).

gamma_proxy = d_ell / d_alpha. The structural mechanism of Section 13.4
predicts gamma_proxy -> 1 at the geometric fixed point. HONESTY: the mapping
of these proxies onto PPN gamma is [P]; equality of the two responses is the
in-model test the document asks for, not yet the Cassini observable.

Binding: V(r) = E(two loads at distance r) - 2 E(one load) + E(0), from the
fermionic ground energy: the matter-mediated interaction between capacity
defects (Goal 4's attraction probe).
"""
from __future__ import annotations
import torch
from .graphs import bfs_partition
from .gaussian import matter_hamiltonian, ground_corr
from .geometry import mi_metric, apsp


def load_region(A, center, radius_hops):
    hop = torch.where(A > 0, 1.0, float("inf"))
    hop.fill_diagonal_(0.0)
    # BFS distances from center
    n = A.shape[0]
    d = torch.full((n,), float("inf"))
    d[center] = 0
    frontier = [center]
    r = 0
    while frontier and r < radius_hops:
        r += 1
        nxt = []
        for u in frontier:
            for v in torch.nonzero(A[u] > 0).flatten().tolist():
                if d[v] == float("inf"):
                    d[v] = r
                    nxt.append(v)
        frontier = nxt
    return torch.nonzero(d <= radius_hops).flatten()


def apply_load(A, region, eps):
    W = A.clone()
    mask = torch.zeros(A.shape[0], dtype=torch.bool)
    mask[region] = True
    inside = mask[:, None] & mask[None, :]
    W[inside] = A[inside] * (1.0 - eps)
    return W


def gamma_probe(A, center, radius_hops=3, eps=0.2, cell_size=4, delta=0.0,
                pattern="none", seed=0):
    n = A.shape[0]
    region = load_region(A, center, radius_hops)
    W = apply_load(A, region, eps)

    def measure(weights):
        H = matter_hamiltonian(weights, delta=delta, pattern=pattern, seed=seed)
        C, _ = ground_corr(H)
        cells = bfs_partition((weights > 0).double(), cell_size, seed=seed)
        L, *_ = mi_metric(C, cells, _cellA(weights, cells))
        D = apsp(L)
        alpha = (H.real ** 2).sum(1).sqrt()
        return H, C, cells, D, alpha

    H0, C0, cells0, D0, a0 = measure(A)
    H1, C1, cells1, D1, a1 = measure(W)

    # clock side: fractional alpha drop inside the region
    d_alpha = float(1.0 - (a1[region] / a0[region]).mean())

    # spatial side: pick anchor cell pairs whose baseline geodesic crosses the
    # region (midpoint criterion), compare loaded vs baseline distance.
    reg_cells0 = _cells_touching(cells0, region)
    reg_cells1 = _cells_touching(cells1, region)
    far0 = _crossing_pairs(D0, reg_cells0)
    if far0.numel() == 0:
        return dict(gamma=float("nan"), d_alpha=d_alpha, d_ell=float("nan"))
    # map anchor cells of partition 0 to partition 1 by shared nodes
    map01 = _match_cells(cells0, cells1, n)
    d_base = D0[far0[:, 0], far0[:, 1]]
    d_load = D1[map01[far0[:, 0]], map01[far0[:, 1]]]
    ok = torch.isfinite(d_base) & torch.isfinite(d_load)
    d_ell = float(((d_load[ok] - d_base[ok]) / d_base[ok]).mean())
    return dict(gamma=d_ell / d_alpha if d_alpha else float("nan"),
                d_alpha=d_alpha, d_ell=d_ell,
                n_pairs=int(ok.sum()), region=int(region.numel()))


def binding_curve(A, centers_pairs, radius_hops=2, eps=0.3, delta=0.5,
                  pattern="stagger", seed=0):
    """V(r) from fermionic ground energies. centers_pairs: list of
    (c1, c2, r_label)."""
    def E_of(weights):
        H = matter_hamiltonian(weights, delta=delta, pattern=pattern, seed=seed)
        w = torch.linalg.eigvalsh(H)
        return float(w[: len(w) // 2].sum())

    E0 = E_of(A)
    singles = {}
    rows = []
    for c1, c2, r in centers_pairs:
        for c in (c1, c2):
            if c not in singles:
                singles[c] = E_of(apply_load(A, load_region(A, c, radius_hops), eps))
        W = apply_load(A, load_region(A, c1, radius_hops), eps)
        W = apply_load(W, load_region(W, c2, radius_hops), eps)
        E12 = E_of(W)
        V = E12 - singles[c1] - singles[c2] + E0
        rows.append((r, V))
    return rows


# ----------------------------- helpers ---------------------------------------
def _cellA(weights, cells):
    from .graphs import cell_adjacency
    return cell_adjacency((weights > 0).double(), cells)


def _cells_touching(cells, region):
    rs = set(region.tolist())
    return torch.tensor([i for i, c in enumerate(cells)
                         if any(x in rs for x in c.tolist())], dtype=torch.long)


def _crossing_pairs(D, reg_cells, n_max=200):
    """Anchor pairs (i, j) outside the region whose midpoint (by triangle
    near-equality through some region cell) suggests the geodesic crosses it."""
    nc = D.shape[0]
    mask = torch.zeros(nc, dtype=torch.bool)
    mask[reg_cells] = True
    out = torch.nonzero(~mask).flatten()
    pairs = []
    for i in out.tolist():
        through = (D[i, reg_cells, None] + D[reg_cells, :][:, out]).min(0).values
        direct = D[i, out]
        good = out[(through <= direct * 1.02) & (direct > 0)]
        for j in good.tolist():
            if j > i:
                pairs.append((i, j))
        if len(pairs) >= n_max:
            break
    return torch.tensor(pairs[:n_max], dtype=torch.long) if pairs else torch.empty(0, 2, dtype=torch.long)


def _match_cells(cells_a, cells_b, n_nodes):
    node2b = torch.empty(n_nodes, dtype=torch.long)
    for i, c in enumerate(cells_b):
        node2b[c] = i
    m = torch.empty(len(cells_a), dtype=torch.long)
    for i, c in enumerate(cells_a):
        m[i] = torch.mode(node2b[c]).values
    return m
