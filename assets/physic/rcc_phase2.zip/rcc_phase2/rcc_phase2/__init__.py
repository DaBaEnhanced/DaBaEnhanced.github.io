"""RCC Phase 2: reconstruction geometry at scale (companion to Appendix I)."""
__version__ = "0.1.0"
