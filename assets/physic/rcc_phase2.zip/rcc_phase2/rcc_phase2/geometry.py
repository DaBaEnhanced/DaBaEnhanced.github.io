"""Reconstruction geometry from correlation data.

Honesty ledger (matches Appendix G.9 and Section 7 of the document):
- The exact one-hop recoverability q_ij is a Petz-decoder transport fidelity.
  At scale we use the CORRELATIONAL PROXY  w_ij = I(i:j) (mutual information,
  Cao-Carroll-Michalakis-style [34]) and the DYNAMICAL PROXY of cone.py
  (propagator influence). Agreement between the two is itself a measurement.
- Edge cost: l_ij = -log q_ij with q_ij = I(i:j) / (2 min(S_i, S_j)),
  using the information-theoretic bound I <= 2 min(S_i, S_j) so that
  q in (0, 1] without any tunable reference: q = 1 (full correlation) means
  zero distance, matching the document's recoverability semantics.
  Distances are reported in units of the median nearest-neighbour spacing;
  dimension and curvature estimators are scale invariant.
Every published number produced by this module should carry the tag
[E, in-model, MI-proxy].
"""
from __future__ import annotations
import torch
from .gaussian import pair_mutual_information, subset_entropies, entropy


# ------------------------------ metric ---------------------------------------
def mi_metric(C, cells, cellA, k_extra=2, l_min=1e-3, i_floor=1e-10):
    """Build cell-level edge costs from MI on contact pairs (cellA[i,j] > 0),
    plus each cell's k_extra strongest non-contact partners (to catch
    shortcut candidates as *edges* rather than missing them).
    Returns (L, pairs, I) with L (ncell, ncell) cost matrix (inf off-edge)."""
    nc = len(cells)
    contact = torch.nonzero(torch.triu(cellA, 1) > 0)
    pairs = contact
    I, S_cell = pair_mutual_information(C, cells, pairs)
    smin = torch.minimum(S_cell[pairs[:, 0]], S_cell[pairs[:, 1]]).clamp_min(i_floor)
    q = (I.clamp_min(i_floor) / (2 * smin)).clamp(max=1.0)
    I0 = float(I.median())
    L = torch.full((nc, nc), float("inf"), device=C.device)
    cost = (-q.log()).clamp_min(l_min)
    L[pairs[:, 0], pairs[:, 1]] = cost
    L[pairs[:, 1], pairs[:, 0]] = cost
    L.fill_diagonal_(0.0)
    return L, pairs, I, S_cell, float(I0)


def apsp(L, chunk=1024):
    """All-pairs shortest paths by min-plus squaring: D <- min(D, D (x) D).
    log2(n) rounds; row-chunked to bound memory. L: (n, n) with inf off-edge."""
    D = L.clone()
    n = D.shape[0]
    rounds = max(1, int(torch.tensor(float(n)).log2().ceil()))
    for _ in range(rounds):
        Dn = torch.empty_like(D)
        for a in range(0, n, chunk):
            Dn[a:a + chunk] = (D[a:a + chunk].unsqueeze(2) + D.unsqueeze(0)).min(dim=1).values
        if torch.equal(Dn, D):
            break
        D = Dn
    return D


def _nn_unit(D):
    """Median nearest-neighbour distance (metric unit)."""
    Dp = D.clone()
    Dp[Dp <= 0] = float("inf")
    nn = Dp.min(dim=1).values
    nn = nn[torch.isfinite(nn)]
    return nn.median().clamp_min(1e-12)


# --------------------------- dimension flow ----------------------------------
def dimension_flow(D, n_r=24):
    """N(r) ball-volume curve and running dimension d(r) = dlogN/dlogr.
    Returns (r_grid, N_mean, d_run). 'Dimension flow' = d(r) across scales."""
    D = D / _nn_unit(D)
    finite = D[torch.isfinite(D) & (D > 0)]
    r_lo, r_hi = torch.quantile(finite, 0.02), torch.quantile(finite, 0.6)
    r = torch.logspace(float(r_lo.log10()), float(r_hi.log10()), n_r, device=D.device)
    N = torch.stack([(D <= ri).double().sum(1).mean() for ri in r])
    lr, lN = r.log(), N.log()
    d_run = (lN[2:] - lN[:-2]) / (lr[2:] - lr[:-2])
    return r, N, d_run


def fit_dimension(D):
    """Scalar d_eff: least-squares slope of log N(r) over the central window,
    plus curvature proxy b from log N = c + d log r + b r^2 (b < 0 suggests
    positive curvature; PROXY ONLY, see Section 7.4)."""
    r, N, _ = dimension_flow(D)
    w = (torch.arange(len(r)) >= 3) & (torch.arange(len(r)) < len(r) - 3)
    X = torch.stack([torch.ones(int(w.sum())), r[w].log(), r[w] ** 2], dim=1)
    beta = torch.linalg.lstsq(X, N[w].log().unsqueeze(1)).solution.flatten()
    return float(beta[1]), float(beta[2])


def spectral_dimension(L, t_grid=None):
    """Spectral dimension from heat-kernel return probability on the weighted
    cell graph (Laplacian of exp(-l) affinities): d_s(t) = -2 dlnP/dlnt."""
    W = torch.exp(-L)
    W[~torch.isfinite(L)] = 0.0
    W.fill_diagonal_(0.0)
    deg = W.sum(1)
    Lap = torch.diag(deg) - W
    ev = torch.linalg.eigvalsh(Lap).clamp_min(0)
    if t_grid is None:
        nz = ev[ev > 1e-10]
        t_grid = torch.logspace(float((1 / nz.max()).log10()),
                                float((1 / nz[0].clamp_min(1e-6)).log10()), 20)
    P = torch.stack([torch.exp(-t * ev).mean() for t in t_grid])
    lt, lP = t_grid.log(), P.log()
    ds = -2 * (lP[2:] - lP[:-2]) / (lt[2:] - lt[:-2])
    return t_grid, ds


# -------------------- covariance of the metric (G.9 window test) -------------
def metric_covariance(D1, cells1, D2, cells2, n_nodes, n_sample=4000, seed=0):
    """Compare two metrics built from different partitions by lifting both to
    node level (node distance := its cell's distance) and correlating over
    random node pairs. Returns (pearson, stress)."""
    g = torch.Generator().manual_seed(seed)
    node2cell1 = torch.empty(n_nodes, dtype=torch.long)
    for i, c in enumerate(cells1):
        node2cell1[c] = i
    node2cell2 = torch.empty(n_nodes, dtype=torch.long)
    for i, c in enumerate(cells2):
        node2cell2[c] = i
    u = torch.randint(0, n_nodes, (n_sample,), generator=g)
    v = torch.randint(0, n_nodes, (n_sample,), generator=g)
    d1 = D1[node2cell1[u], node2cell1[v]].cpu()
    d2 = D2[node2cell2[u], node2cell2[v]].cpu()
    ok = torch.isfinite(d1) & torch.isfinite(d2) & (u != v)
    d1, d2 = d1[ok], d2[ok]
    s = (d1 * d2).sum() / (d2 * d2).sum()
    stress = float(((d1 - s * d2) ** 2).sum().sqrt() / (d1 ** 2).sum().sqrt())
    pearson = float(torch.corrcoef(torch.stack([d1, d2]))[0, 1])
    return pearson, stress


# ------------------------------ shortcuts ------------------------------------
def shortcut_scan(C, cells, D, n_far=400, factor=3.0, seed=0):
    """MI between far cell pairs (d_R > factor * median NN spacing). A
    'shortcut' is a far pair whose MI exceeds the median nearest-neighbour MI.
    Returns (count, max_far_MI / I0_nn, sampled pairs)."""
    g = torch.Generator().manual_seed(seed)
    nc = len(cells)
    med = _nn_unit(D)
    cand = torch.nonzero(torch.triu(D, 1) > factor * med)
    if cand.numel() == 0:
        return 0, 0.0, None
    sel = cand if cand.shape[0] <= n_far else \
        cand[torch.randperm(cand.shape[0], generator=g)[:n_far]]
    I_far, _ = pair_mutual_information(C, cells, sel)
    # nearest-neighbour reference
    nn = torch.nonzero((D > 0) & (D <= torch.quantile(D[D > 0], 0.05)))
    nn = nn[torch.randperm(nn.shape[0], generator=g)[:200]]
    I_nn, _ = pair_mutual_information(C, cells, nn)
    I0 = torch.quantile(I_nn, 0.5)
    count = int((I_far > I0).sum())
    return count, float(I_far.max() / I0.clamp_min(1e-12)), sel


# ------------------------------ area law -------------------------------------
def area_law_scan(C, A, centers, radii):
    """S(ball) vs boundary size |∂ball| via graph BFS balls. Returns rows of
    (radius, |ball|, |boundary|, S)."""
    n = A.shape[0]
    rows = []
    hop = apsp(torch.where(A > 0, torch.ones_like(A), torch.full_like(A, float("inf"))
                           ).fill_diagonal_(0))
    for c in centers:
        for r in radii:
            ball = torch.nonzero(hop[c] <= r).flatten()
            if ball.numel() < 2 or ball.numel() > n - 2:
                continue
            inb = torch.zeros(n, dtype=torch.bool)
            inb[ball] = True
            bnd = int((A[ball][:, ~inb] > 0).sum())
            rows.append((int(r), int(ball.numel()), bnd, entropy(C, ball)))
    return rows
