"""Dynamical-graph Monte Carlo with fermionic matter (Goal 1: does a geometric
phase form?). Each rank runs one rung of a parallel-tempering ladder; replica
exchange goes through Comm. Moves are single-edge rewires at fixed node set.

Energy: E(G) = E_fermion_ground(G) + graph_energy(G) (Section 24.4 terms).
The locality term uses the current emergent metric, refreshed every
`metric_every` sweeps (frozen in between; standard adiabatic approximation).
"""
from __future__ import annotations
import math
import torch
from .graphs import graph_energy, bfs_partition, cell_adjacency
from .gaussian import matter_hamiltonian, ground_corr
from .geometry import mi_metric, apsp, fit_dimension
from .cone import lift_to_nodes


def fermion_energy(A, delta, pattern, seed):
    H = matter_hamiltonian(A, delta=delta, pattern=pattern, seed=seed)
    w = torch.linalg.eigvalsh(H)
    return float(w[: len(w) // 2].sum())


def propose_rewire(A, gen):
    """Pick a random edge (u, v) and random non-edge (u, w); move v -> w."""
    n = A.shape[0]
    edges = torch.nonzero(torch.triu(A, 1) > 0)
    e = edges[torch.randint(0, edges.shape[0], (1,), generator=gen)][0]
    u, v = int(e[0]), int(e[1])
    for _ in range(50):
        w = int(torch.randint(0, n, (1,), generator=gen))
        if w != u and w != v and A[u, w] == 0:
            B = A.clone()
            B[u, v] = B[v, u] = 0.0
            B[u, w] = B[w, u] = 1.0
            return B, (u, v, w)
    return None, None


def run_anneal(comm, A0, steps=2000, T_hi=2.0, T_lo=0.05, z0=6.0, mu=0.5,
               tri=0.1, lam=0.05, delta=0.5, pattern="random", matter=True,
               metric_every=200, cell_size=4, swap_every=50, seed=0, log=None):
    rank, world = comm.rank, comm.world
    # geometric temperature ladder across ranks
    T = T_hi * (T_lo / T_hi) ** (rank / max(1, world - 1)) if world > 1 else T_lo
    gen = torch.Generator().manual_seed(seed + 1000 * rank)
    A = A0.clone()
    D_node = None

    def total_E(G, Dn):
        e = float(graph_energy(G, z0=z0, mu=mu, tri=tri, lam=lam, D=Dn))
        if matter:
            e += fermion_energy(G, delta, pattern, seed)
        return e

    def refresh_metric(G):
        H = matter_hamiltonian(G, delta=delta, pattern=pattern, seed=seed)
        C, _ = ground_corr(H)
        cells = bfs_partition(G, cell_size, seed=seed)
        L, *_ = mi_metric(C, cells, cell_adjacency(G, cells))
        D = apsp(L)
        d_eff, curv = fit_dimension(D)
        return lift_to_nodes(D, cells, G.shape[0]), d_eff, curv

    if lam:
        D_node, d_eff, curv = refresh_metric(A)
    else:
        d_eff, curv = float("nan"), float("nan")
    E = total_E(A, D_node)
    acc = 0
    for t in range(steps):
        B, mv = propose_rewire(A, gen)
        if B is None:
            continue
        E2 = total_E(B, D_node)
        if E2 <= E or torch.rand(1, generator=gen).item() < math.exp(-(E2 - E) / T):
            A, E = B, E2
            acc += 1
        if lam and (t + 1) % metric_every == 0:
            D_node, d_eff, curv = refresh_metric(A)
            E = total_E(A, D_node)
        if world > 1 and (t + 1) % swap_every == 0:
            # deterministic even/odd pairing; exchange energies, swap configs
            phase = ((t + 1) // swap_every) % 2
            partner = rank + 1 if (rank % 2 == phase) else rank - 1
            if 0 <= partner < world:
                E_p = comm.exchange_scalar(E, partner)
                T_p = T_hi * (T_lo / T_hi) ** (partner / max(1, world - 1))
                # shared decision via shared seed on the swap index
                u = torch.rand(1, generator=torch.Generator().manual_seed(
                    seed + (t + 1))).item()
                if u < math.exp((E - E_p) * (1 / T - 1 / T_p)):
                    # swap configurations by broadcast trade
                    A_p = comm.broadcast_obj(A.cpu(), src=min(rank, partner))
                    A_q = comm.broadcast_obj(A.cpu(), src=max(rank, partner))
                    A = (A_q if rank < partner else A_p).to(A.device)
                    E = total_E(A, D_node)
        if log is not None and (t + 1) % 50 == 0:
            deg = A.sum(1)
            log(dict(step=t + 1, rank=rank, T=T, E=E,
                     acc=acc / (t + 1), deg_mean=float(deg.mean()),
                     deg_max=float(deg.max()), d_eff=d_eff, curv=curv))
    return A, E, dict(T=T, acc=acc / max(1, steps), d_eff=d_eff, curv=curv)
