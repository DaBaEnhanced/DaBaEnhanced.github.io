"""Graph construction, BFS cell partitions, and H_graph energy terms."""
from __future__ import annotations
import torch


def lattice(dims, periodic=True):
    """Hypercubic lattice adjacency (n, n) float tensor. dims e.g. (24, 24)."""
    import itertools
    sizes = list(dims)
    n = 1
    for s in sizes:
        n *= s
    idx = {c: i for i, c in enumerate(itertools.product(*[range(s) for s in sizes]))}
    A = torch.zeros(n, n)
    for c, i in idx.items():
        for d in range(len(sizes)):
            cc = list(c)
            cc[d] += 1
            if cc[d] == sizes[d]:
                if not periodic:
                    continue
                cc[d] = 0
            j = idx[tuple(cc)]
            A[i, j] = A[j, i] = 1.0
    return A


def random_regular(n, z, seed=0):
    """Random z-regular graph via configuration model with retries."""
    g = torch.Generator().manual_seed(seed)
    for _ in range(200):
        stubs = torch.repeat_interleave(torch.arange(n), z)
        perm = torch.randperm(stubs.numel(), generator=g)
        stubs = stubs[perm]
        a, b = stubs[0::2], stubs[1::2]
        ok = (a != b)
        A = torch.zeros(n, n)
        A[a[ok], b[ok]] = 1.0
        A = ((A + A.T) > 0).double()
        if int(A.sum(1).min()) >= z - 1:  # tolerate rare defects
            return A
    raise RuntimeError("random_regular failed")


def bfs_partition(A, cell_size, seed=0):
    """Greedy BFS partition of nodes into contiguous cells of ~cell_size.
    Returns list of LongTensors (cells)."""
    n = A.shape[0]
    g = torch.Generator().manual_seed(seed)
    unassigned = torch.ones(n, dtype=torch.bool)
    nbrs = [torch.nonzero(A[i] > 0).flatten() for i in range(n)]
    cells = []
    order = torch.randperm(n, generator=g)
    for s in order.tolist():
        if not unassigned[s]:
            continue
        cell, frontier = [s], [s]
        unassigned[s] = False
        while frontier and len(cell) < cell_size:
            nxt = []
            for u in frontier:
                for v in nbrs[u].tolist():
                    if unassigned[v] and len(cell) < cell_size:
                        unassigned[v] = False
                        cell.append(v)
                        nxt.append(v)
            frontier = nxt
        cells.append(torch.tensor(cell, dtype=torch.long))
    return cells


def cell_adjacency(A, cells):
    """(ncell, ncell) count of graph edges between cells."""
    n = len(cells)
    M = torch.zeros(n, A.shape[0])
    for i, c in enumerate(cells):
        M[i, c] = 1.0
    B = M @ A @ M.T
    B.fill_diagonal_(0)
    return B


# ----------------------- H_graph energy terms (Section 24.4) -----------------
def graph_energy(A, z0=6.0, mu=1.0, tri=0.1, lam=0.0, D=None):
    """E_graph = mu * sum (deg - z0)^2 - tri * (#triangles) + lam * sum_e d_R(e).
    D: optional current cell-level reconstruction metric lifted to nodes; the
    locality term is frozen between metric refreshes (see anneal.py)."""
    deg = A.sum(1)
    e = mu * ((deg - z0) ** 2).sum()
    e = e - tri * torch.trace(A @ A @ A) / 6.0
    if lam and D is not None:
        e = e + lam * (A * D).sum() / 2.0
    return e
