"""Geodesic propagation and the influence cone, measured in the EMERGENT
metric d_R rather than in graph hops.

Propagator front: G(t) = exp(-i H t); signal_j(t) = |G_{j, src}|^2 is the
single-particle influence proxy (the dynamical face of Postulate 5). The
front radius r_f(t) is the largest emergent distance at which the signal
exceeds a threshold; the cone speed is its late-time slope, and isotropy is
its spread across directions/sources.
"""
from __future__ import annotations
import torch


def propagator_front(H, D_node, sources, t_grid, eta=1e-6):
    """H: (n, n) single-particle Hamiltonian. D_node: (n, n) emergent node
    distances (cell metric lifted to nodes). Returns fronts (S, T) and speeds
    per source."""
    w, V = torch.linalg.eigh(H)
    fronts = torch.zeros(len(sources), len(t_grid))
    for si, s in enumerate(sources):
        amp0 = V.conj()[s]                                # (n_modes,) row of V^dagger e_s
        for ti, t in enumerate(t_grid):
            ph = torch.exp(-1j * w * t)
            psi = (V * (ph * amp0)).sum(-1)                # G(t) e_s
            sig = psi.abs() ** 2
            hit = sig > eta
            fronts[si, ti] = D_node[s][hit].max() if hit.any() else 0.0
    speeds = []
    for si in range(len(sources)):
        y = fronts[si]
        # fit the rising portion only (finite systems saturate at the diameter)
        rising = y < 0.9 * y.max()
        rising[0] = True
        if int(rising.sum()) < 3:
            rising = torch.ones_like(rising, dtype=torch.bool)
        tt, yy = t_grid[rising], y[rising]
        sl = torch.linalg.lstsq(
            torch.stack([torch.ones(len(tt)), tt], 1),
            yy.unsqueeze(1)).solution[1, 0]
        speeds.append(float(sl))
    speeds = torch.tensor(speeds)
    return fronts, speeds, float(speeds.mean()), float(speeds.std())


def lift_to_nodes(D_cell, cells, n_nodes):
    node2cell = torch.empty(n_nodes, dtype=torch.long)
    for i, c in enumerate(cells):
        node2cell[c] = i
    return D_cell[node2cell][:, node2cell]
