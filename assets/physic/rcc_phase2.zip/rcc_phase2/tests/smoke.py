"""Correctness smoke tests (CPU, small sizes). Run: python tests/smoke.py"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import math
import torch
torch.set_default_dtype(torch.float64)

from rcc_phase2.graphs import lattice, random_regular, bfs_partition, cell_adjacency
from rcc_phase2.gaussian import matter_hamiltonian, ground_corr, entropy, \
    pair_mutual_information
from rcc_phase2.geometry import mi_metric, apsp, fit_dimension, dimension_flow, \
    spectral_dimension, metric_covariance, shortcut_scan, area_law_scan
from rcc_phase2.cone import propagator_front, lift_to_nodes
from rcc_phase2.strain import gamma_probe, binding_curve
from rcc_phase2.anneal import run_anneal


class C1:  # single-process comm stub for anneal test
    rank, world = 0, 1
    device = torch.device("cpu")
    def exchange_scalar(self, v, p): return v
    def broadcast_obj(self, o, src=0): return o


def check(name, cond, detail=""):
    print(f"  [{'OK' if cond else 'FAIL'}] {name} {detail}")
    if not cond:
        raise SystemExit(f"smoke test failed: {name}")


print("[1] entropy of a shared fermion")
C = torch.tensor([[0.5, 0.5], [0.5, 0.5]])
S = entropy(C, torch.tensor([0]))
check("S(site) = ln 2", abs(S - math.log(2)) < 1e-9, f"S={S:.6f}")

print("[2] APSP vs scipy")
import numpy as np
from scipy.sparse.csgraph import shortest_path
g = torch.Generator().manual_seed(3)
W = torch.rand(30, 30, generator=g)
W = (W + W.T) / 2
mask = torch.rand(30, 30, generator=g) < 0.85
L = torch.where(mask | mask.T, torch.full_like(W, float("inf")), W)
L.fill_diagonal_(0)
D = apsp(L)
Dsp = torch.tensor(shortest_path(np.where(np.isinf(L.numpy()), 0, L.numpy()),
                                 method="FW", directed=False))
check("min-plus APSP == Floyd-Warshall", torch.allclose(D, Dsp, atol=1e-9),
      f"max diff {float((D - Dsp).abs().max()):.2e}")

print("[3] dimension of controls (critical fermions, MI metric)")
for name, A, want in [("1D ring", lattice((64,)), 1.0), ("2D lattice", lattice((16, 16)), 2.0)]:
    H = matter_hamiltonian(A)
    Cm, _ = ground_corr(H)
    cells = bfs_partition(A, 2, seed=0)
    Lm, *_ = mi_metric(Cm, cells, cell_adjacency(A, cells))
    D = apsp(Lm)
    d_eff, curv = fit_dimension(D)
    check(f"d_eff({name}) ~ {want}", abs(d_eff - want) < 0.35, f"d_eff={d_eff:.2f} curv={curv:.3f}")

print("[4] cone speed on a 1D ring (v_max = 2J)")
A = lattice((128,))
H = matter_hamiltonian(A)
hops = torch.where(A > 0, torch.ones_like(A), torch.full_like(A, float("inf")))
hops.fill_diagonal_(0)
Dn = apsp(hops)
fronts, speeds, v_mean, v_std = propagator_front(H, Dn, [0, 31], torch.linspace(2, 25, 12))
check("v ~ 2J", abs(v_mean - 2.0) < 0.25, f"v={v_mean:.3f} +/- {v_std:.3f}")

print("[5] area law: gapped 2D vs critical 2D")
A = lattice((14, 14))
rows_g = area_law_scan(ground_corr(matter_hamiltonian(A, delta=1.0, pattern="stagger"))[0],
                       A, [0], list(range(1, 6)))
rows_c = area_law_scan(ground_corr(matter_hamiltonian(A))[0], A, [0], list(range(1, 6)))
sg = [r[3] / r[2] for r in rows_g]   # S / boundary
sc = [r[3] / r[2] for r in rows_c]
check("gapped S/|dA| flat-ish", max(sg) / min(sg) < 1.6,
      f"S/boundary: {['%.3f' % x for x in sg]}")
print(f"      critical S/boundary (log growth expected): {['%.3f' % x for x in sc]}")

print("[6] metric partition covariance on 2D lattice")
A = lattice((16, 16))
Cm, _ = ground_corr(matter_hamiltonian(A))
c1 = bfs_partition(A, 4, seed=0); c2 = bfs_partition(A, 4, seed=9)
L1, *_ = mi_metric(Cm, c1, cell_adjacency(A, c1)); D1 = apsp(L1)
L2, *_ = mi_metric(Cm, c2, cell_adjacency(A, c2)); D2 = apsp(L2)
pear, stress = metric_covariance(D1, c1, D2, c2, A.shape[0])
# Finite-size: pearson rises toward 1 with system size (0.77/0.88/0.93 at
# L=12/16/24); the scaling itself is the cluster-scale G.9 measurement.
check("pearson > 0.8 at L=16", pear > 0.8, f"pearson={pear:.3f} stress={stress:.3f}")

print("[7] shortcut scan: lattice clean vs wormhole-wired lattice")
n_sc, ratio, _ = shortcut_scan(Cm, c1, D1, n_far=10**6)
Aw = A.clone()
for a, b in [(3, 200), (4, 201), (19, 216)]:   # a 3-strand nonlocal wire
    Aw[a, b] = Aw[b, a] = 1.0
Cw, _ = ground_corr(matter_hamiltonian(Aw))
# metric built from the CLEAN adjacency (so the wire is a genuine shortcut)
n_sc_w, ratio_w, _ = shortcut_scan(Cw, c1, D1, n_far=10**6)
check("clean lattice has fewer/weaker shortcuts than wired one",
      ratio_w > ratio, f"clean ratio={ratio:.2f}, wired ratio={ratio_w:.2f}")

print("[8] gamma probe runs and is O(1)")
out = gamma_probe(lattice((14, 14)), center=14 * 7 + 7, radius_hops=2, eps=0.3,
                  cell_size=2)
check("gamma finite", math.isfinite(out["gamma"]), f"{out}")

print("[9] binding curve decays")
A = lattice((16, 16))
c0 = 8 * 16 + 2
rows = binding_curve(A, [(c0, c0 + r, r) for r in (3, 5, 7, 9)])
mags = [abs(v) for _, v in rows]
check("|V| decreasing", mags[0] > mags[-1], f"V(r): {[(r, '%.2e' % v) for r, v in rows]}")

print("[10] anneal runs (no matter, tiny)")
A0 = random_regular(36, 4, seed=0)
A, E, info = run_anneal(C1(), A0, steps=60, matter=False, lam=0.0, z0=4,
                        swap_every=10**9, log=None)
check("anneal finished", torch.isfinite(torch.tensor(E)), f"E={E:.2f} acc={info['acc']:.2f}")

print("\nALL SMOKE TESTS PASSED")
