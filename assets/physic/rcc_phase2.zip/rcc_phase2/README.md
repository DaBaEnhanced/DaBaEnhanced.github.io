# RCC Phase 2 — reconstruction geometry at scale

Companion code to "The Recurrent Causal Code" v0.4+, roadmap Phase 2 (§25):
**emergent metric, dimension flow, curvature estimators, geodesic propagation**,
plus the Goal-1 checklist (§22.1: cone universality, area law, foliation
covariance, shortcut absence) and the γ probe (§13.4).

Matter sector: free fermions (Gaussian states) on static or annealed graphs —
the largest system class where entropies, mutual information, and propagators
are *exact*, so every geometric quantity is a controlled measurement rather
than a variational estimate. All heavy math is batched `torch.linalg` in fp64
and runs on GPU. Ranks are replicas (independent seeds) or parallel-tempering
rungs; there is no gradient traffic, so scaling is embarrassingly parallel.

## Install

```bash
pip install torch lightning-fabric scipy      # scipy only needed for tests
python tests/smoke.py                          # ~2-10 min on CPU; all must pass
```

`lightning-fabric` is the primary launcher; without it the code falls back to
raw `torch.distributed` (torchrun/SLURM env) and then to single-process.

## Running

```bash
# laptop / single GPU
python run.py --exp metric --graph lat2d --side 24 --cell 4

# single node, 8 GPUs (8 replicas, different seeds)
python run.py --exp metric --devices 8 --side 48

# SLURM multi-node (Fabric reads SLURM env; one task per GPU)
srun --ntasks-per-node=8 --gpus-per-task=1 python run.py --exp anneal --devices auto

# torchrun alternative
torchrun --nproc_per_node=8 run.py --exp cone --side 64
```

Results land in `out/<exp>_results.json` (rank 0 aggregates all replicas);
`anneal` also writes per-rank JSONL logs and graph checkpoints.

## Experiments → Phase-2 deliverables

| `--exp` | Measures | Deliverable / checklist item |
|---|---|---|
| `metric` | MI metric `d_R`; running dimension d(r) (**dimension flow**); ball-volume **curvature proxy**; spectral dimension; partition-covariance (pearson/stress) = G.9 window test; shortcut scan (§7.2); area-law scan | emergent metric, dimension flow, curvature estimators, foliation-covariance proxy, shortcut absence, area law |
| `cone` | propagator front in the **emergent** metric; speed mean/std over sources → isotropy | geodesic propagation, universal cone |
| `strain` | γ_proxy = d_ell/d_alpha under a capacity load; two-load binding V(r) | §13.4 γ probe; Goal-4 attraction probe |
| `anneal` | parallel-tempering graph MC with fermionic matter; degree, d_eff, curvature along the flow | Goal 1: does a geometric phase form? (bridge to Phase 3) |

Suggested production scans (each point = one replica-rank):
- `metric`: side ∈ {32, 48, 64, 96} × {lat2d, lat3d, randreg} × pattern ∈ {none, stagger}; the partition-pearson → 1 trend with side is the covariance measurement (0.77/0.88/0.93 at L = 12/16/24 on CPU already).
- `cone`: same grid; v_std/v_mean vs side is the cone-universality estimator.
- `strain`: eps ∈ {0.05..0.4} × load_r ∈ {2..6} × side ∈ {24..64} × gapped/critical. **Preliminary CPU result at L=20: γ_proxy ≈ 0.01–0.04 ≪ 1** (clock side responds at O(ε), MI-metric side ~10⁻³). If this persists at scale, the §13.4 structural mechanism fails in this free-fermion + MI-proxy realization — report it; the kill-criterion framework exists for exactly this.
- `anneal`: world = temperature rungs (8–32); steps 10⁴–10⁵; with `--matter` each step costs one `eigvalsh` (n≤2048 comfortably on A100-class fp64).

## Honesty ledger (tags per the document)

- Edge weights use q_ij = I(i:j)/(2·min(S_i,S_j)) ∈ (0,1] — the MI proxy for
  Petz-decoder recoverability (G.9). Correlational proxy [E, in-model,
  MI-proxy]; equivalence to the operational q is [P]. `cone` provides the
  independent dynamical (influence) proxy; agreement between the two is itself
  a measurement of Postulate 5.
- "Foliation covariance" is tested here as partition/scale covariance of d_R
  in a Hamiltonian ground state; true cut-covariance in the circuit picture
  remains [P] (G.10).
- The curvature number is a ball-volume-deficit proxy (§7.4), not a theorem.
- γ_proxy maps onto PPN γ only through the strain dictionary of §12–13, which
  is [P]; equality of the two fractional responses is the in-model test.

## Layout

```
rcc_phase2/comm.py       Fabric / torch.distributed / single-process wrapper
rcc_phase2/graphs.py     lattices, random-regular, BFS cells, H_graph terms
rcc_phase2/gaussian.py   ground-state correlations, batched entropies, MI
rcc_phase2/geometry.py   metric, APSP (min-plus, chunked), dimension flow,
                         curvature, covariance, shortcuts, area law
rcc_phase2/cone.py       propagator fronts in the emergent metric
rcc_phase2/strain.py     γ probe, binding curve
rcc_phase2/anneal.py     parallel-tempering graph Monte Carlo
run.py                   CLI dispatcher (presets above)
tests/smoke.py           10 correctness tests against known physics
```

Numerical conventions: entropies in nats; distances in units of the median
nearest-neighbour spacing; fp64 throughout (do not run geometry in fp32).
