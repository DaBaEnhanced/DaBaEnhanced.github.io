#!/usr/bin/env python3
"""RCC Phase 2 experiment runner.

Experiments (Section 25 Phase 2 deliverables + Goal 1 checklist):
  metric    emergent metric, dimension flow, curvature proxy, spectral dim,
            partition-covariance (G.9 window test), shortcut scan, area law
  cone      geodesic propagation: influence front in the emergent metric,
            speed and isotropy across sources
  strain    gamma probe (d_ell / d_alpha under a capacity load) + binding V(r)
  anneal    dynamical-graph parallel tempering with fermionic matter (Goal 1)

Multi-GPU / cluster:
  single node : python run.py --exp metric --devices 4
  SLURM       : srun python run.py --exp anneal --devices auto
  torchrun    : torchrun --nproc_per_node=8 run.py --exp anneal
Ranks act as replicas (independent seeds) except in `anneal`, where they form
a parallel-tempering ladder. fp64 everywhere (geometry needs it).
"""
from __future__ import annotations
import argparse
import json
import torch

from rcc_phase2.comm import Comm
from rcc_phase2.graphs import lattice, random_regular, bfs_partition, cell_adjacency
from rcc_phase2.gaussian import matter_hamiltonian, ground_corr
from rcc_phase2.geometry import (mi_metric, apsp, dimension_flow, fit_dimension,
                                 spectral_dimension, metric_covariance,
                                 shortcut_scan, area_law_scan)
from rcc_phase2.cone import propagator_front, lift_to_nodes
from rcc_phase2.strain import gamma_probe, binding_curve
from rcc_phase2.anneal import run_anneal
from rcc_phase2.io_utils import Logger, save_ckpt


def build_graph(args, seed):
    if args.graph == "lat2d":
        return lattice((args.side, args.side))
    if args.graph == "lat3d":
        return lattice((args.side, args.side, args.side))
    if args.graph == "randreg":
        return random_regular(args.side ** 2, args.z, seed=seed)
    raise ValueError(args.graph)


def prepare_state(A, args, seed, device):
    A = A.to(device)
    H = matter_hamiltonian(A, delta=args.delta, pattern=args.pattern, seed=seed)
    C, w = ground_corr(H)
    cells = bfs_partition(A.cpu(), args.cell, seed=seed)
    cells = [c for c in cells]
    L, pairs, I, S_cell, I0 = mi_metric(C, cells, cell_adjacency(A.cpu(), cells).to(device))
    D = apsp(L)
    return A, H, C, cells, L, D, I0


def exp_metric(comm, args):
    seed = args.seed + comm.rank
    A, H, C, cells, L, D, I0 = prepare_state(build_graph(args, seed), args, seed, comm.device)
    r, N, d_run = dimension_flow(D)
    d_eff, curv = fit_dimension(D)
    tg, ds = spectral_dimension(L)
    # partition covariance: rebuild with a different partition seed
    cells2 = bfs_partition(A.cpu(), args.cell, seed=seed + 777)
    L2, *_ = mi_metric(C, cells2, cell_adjacency(A.cpu(), cells2).to(comm.device))
    D2 = apsp(L2)
    pear, stress = metric_covariance(D.cpu(), cells, D2.cpu(), cells2, A.shape[0])
    n_sc, ratio_sc, _ = shortcut_scan(C, cells, D)
    centers = torch.linspace(0, A.shape[0] - 1, 4).long().tolist()
    area = area_law_scan(C, A.cpu(), centers, radii=list(range(1, args.side // 2)))
    res = dict(exp="metric", rank=comm.rank, graph=args.graph, n=int(A.shape[0]),
               delta=args.delta, pattern=args.pattern,
               d_eff=d_eff, curv_proxy=curv,
               d_run=[float(x) for x in d_run],
               d_spectral=[float(x) for x in ds],
               partition_pearson=pear, partition_stress=stress,
               shortcuts=n_sc, shortcut_ratio=ratio_sc,
               area_law=area, I0=I0)
    return res


def exp_cone(comm, args):
    seed = args.seed + comm.rank
    A, H, C, cells, L, D, I0 = prepare_state(build_graph(args, seed), args, seed, comm.device)
    Dn = lift_to_nodes(D, cells, A.shape[0]).to(comm.device)
    g = torch.Generator().manual_seed(seed)
    sources = torch.randint(0, A.shape[0], (args.n_sources,), generator=g).tolist()
    t_grid = torch.linspace(0.5, args.t_max, args.n_t)
    fronts, speeds, v_mean, v_std = propagator_front(H, Dn, sources, t_grid)
    return dict(exp="cone", rank=comm.rank, graph=args.graph, n=int(A.shape[0]),
                v_mean=v_mean, v_std=v_std, v_iso=v_std / max(v_mean, 1e-12),
                speeds=[float(s) for s in speeds],
                fronts=fronts.tolist(), t_grid=t_grid.tolist())


def exp_strain(comm, args):
    seed = args.seed + comm.rank
    A = build_graph(args, seed)
    center = A.shape[0] // 2
    out = gamma_probe(A, center, radius_hops=args.load_r, eps=args.eps,
                      cell_size=args.cell, delta=args.delta, pattern=args.pattern,
                      seed=seed)
    # binding on the same graph (gapped matter recommended)
    side = args.side
    if args.graph == "lat2d":
        c0 = (side // 2) * side + 2
        pairs = [(c0, c0 + r, r) for r in range(3, side - 4, 2)]
        out["binding"] = binding_curve(A, pairs, radius_hops=1, eps=args.eps,
                                       delta=max(args.delta, 0.5),
                                       pattern="stagger", seed=seed)
    out.update(exp="strain", rank=comm.rank, eps=args.eps, graph=args.graph)
    return out


def exp_anneal(comm, args):
    seed = args.seed
    A0 = random_regular(args.side ** 2, args.z, seed=seed).to(comm.device)
    log = Logger(args.out, comm.rank)
    A, E, info = run_anneal(comm, A0, steps=args.steps, z0=args.z, mu=0.5,
                            tri=args.tri, lam=args.lam, delta=args.delta,
                            pattern="random", matter=args.matter,
                            cell_size=args.cell, seed=seed, log=log)
    save_ckpt(args.out, comm.rank, A=A)
    return dict(exp="anneal", rank=comm.rank, E=E, **info)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--exp", required=True,
                   choices=["metric", "cone", "strain", "anneal"])
    p.add_argument("--graph", default="lat2d", choices=["lat2d", "lat3d", "randreg"])
    p.add_argument("--side", type=int, default=24)
    p.add_argument("--z", type=int, default=6)
    p.add_argument("--cell", type=int, default=4)
    p.add_argument("--delta", type=float, default=0.0)
    p.add_argument("--pattern", default="none", choices=["none", "stagger", "random"])
    p.add_argument("--eps", type=float, default=0.2)
    p.add_argument("--load_r", type=int, default=3)
    p.add_argument("--t_max", type=float, default=20.0)
    p.add_argument("--n_t", type=int, default=24)
    p.add_argument("--n_sources", type=int, default=8)
    p.add_argument("--steps", type=int, default=2000)
    p.add_argument("--tri", type=float, default=0.1)
    p.add_argument("--lam", type=float, default=0.05)
    p.add_argument("--matter", action="store_true")
    p.add_argument("--devices", default="auto")
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--out", default="out")
    args = p.parse_args()
    try:
        args.devices = int(args.devices)
    except ValueError:
        pass

    comm = Comm(devices=args.devices)
    fn = dict(metric=exp_metric, cone=exp_cone, strain=exp_strain,
              anneal=exp_anneal)[args.exp]
    res = fn(comm, args)
    all_res = comm.gather_obj(res)
    if comm.rank == 0:
        import os
        os.makedirs(args.out, exist_ok=True)
        path = f"{args.out}/{args.exp}_results.json"
        with open(path, "w") as f:
            json.dump(all_res, f, indent=1)
        brief = {k: v for k, v in all_res[0].items()
                 if not isinstance(v, (list, dict))}
        print(f"[rank0] wrote {path}")
        print(f"[rank0] first-replica summary: {brief}")


if __name__ == "__main__":
    main()
